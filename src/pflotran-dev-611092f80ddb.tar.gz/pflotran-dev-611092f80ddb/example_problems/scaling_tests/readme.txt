This directory contains versions of the "regional doublet" problem from the 
PFLOTRAN short course that have been specifically constructed for solver 
scalability tests.  They have been put in version control to make it easier 
to track exactly what benchmark problems are being run.
