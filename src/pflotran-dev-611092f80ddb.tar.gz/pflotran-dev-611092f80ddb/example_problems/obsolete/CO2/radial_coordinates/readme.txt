Radial injection problem with uniform grid spacing. 

A constant injection rate of 0.1 kg/s over 64 meter depth is used.

No-flow boundary conditions at top and bottom. Fixed pressure boundary 
condition of 2e7 Pa at east face.

mpirun -np xxx pflotran snes_ls basic

