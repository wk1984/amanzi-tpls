#define MAXBCREGIONS 500000
#define MAXBCBLOCKS 500000
#define MAXSTRINGLENGTH 256
#define MAXWORDLENGTH 32
#define MAXCARDLENGTH 4
#define MAXNAMELENGTH 20
#define MAXPERMREGIONS 35000
#define MAXINITREGIONS 3500
#define MAXSRC 10
#define MAXSRCTIMES 100
#define IUNIT1 15
#define IUNIT2 16
#define IUNIT3 17
#define IUNIT4 18
#define HHISTORY_LENGTH 1000
! HHISTORY_LENGTH is the length of the array used to store the differencing
! values h.
