extern "C"

void pflow_loc_(void** return_arg, void* pointer_arg)
{
   *return_arg = pointer_arg;
}
