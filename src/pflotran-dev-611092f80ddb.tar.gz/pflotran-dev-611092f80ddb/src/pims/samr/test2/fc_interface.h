#ifndef fc_interface_h
#define fc_interface_h
extern "C"{
   void f_create_local_patch_data_(void **p_data);
   void f_create_hierarchy_data_(void **p_data, void **p_hierarchy);
}

#endif
