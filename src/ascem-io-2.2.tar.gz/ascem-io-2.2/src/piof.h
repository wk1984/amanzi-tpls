!*******************************************************************************
! Copyright Notice
!  + 2010-2012 North Carolina State University
!  + 2010-2012 Pacific Northwest National Laboratory
! 
! This file is part of ASCEM-IO.
! 
! ASCEM-IO is free software: you can redistribute it and/or modify
! it under the terms of the GNU Lesser General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! any later version.
! 
! ASCEM-IO is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
! GNU Lesser General Public License for more details.
! 
! You should have received a copy of the GNU Lesser General Public License
! along with ASCEM-IO.  If not, see <http://www.gnu.org/licenses/>.
! 
!*******************************************************************************
!     Fortran Parallel IO interface - Constants declaration

        INTEGER UNIFORM_CONTIGUOUS_READ, NONUNIFORM_CONTIGUOUS_READ, NONCONTIGUOUS_READ, EVERYONE_ENTIRE_DATASET_READ
		INTEGER UNIFORM_CONTIGUOUS_WRITE, NONUNIFORM_CONTIGUOUS_WRITE, NONCONTIGUOUS_WRITE 

        PARAMETER (UNIFORM_CONTIGUOUS_READ=0, NONUNIFORM_CONTIGUOUS_READ=1, NONCONTIGUOUS_READ=2, EVERYONE_ENTIRE_DATASET_READ=3)
		PARAMETER (UNIFORM_CONTIGUOUS_WRITE=4, NONUNIFORM_CONTIGUOUS_WRITE=5, NONCONTIGUOUS_WRITE=6)

        INTEGER FILE_CREATE, FILE_READONLY, FILE_READWRITE
        PARAMETER (FILE_CREATE=0, FILE_READONLY=1, FILE_READWRITE=2)

        INTEGER PIO_INTEGER, PIO_DOUBLE, PIO_FLOAT, PIO_LONG, PIO_CHAR, PIO_BYTE
        PARAMETER (PIO_INTEGER=0, PIO_DOUBLE=1, PIO_FLOAT=2, PIO_LONG=3, PIO_CHAR=4, PIO_BYTE=5)

