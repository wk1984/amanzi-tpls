/* src/parallel/moab_mpi_config.h.  Generated from moab_mpi_config.h.in by configure.  */
/* MPICH_IGNORE_CXX_SEEK is not sufficient to avoid conflicts */
/* #undef MB_MPI_CXX_CONFLICT */

/* "Value of C SEEK_CUR" */
/* #undef MB_SEEK_CUR */

/* "Value of C SEEK_END" */
/* #undef MB_SEEK_END */

/* "Value of C SEEK_SET" */
/* #undef MB_SEEK_SET */
