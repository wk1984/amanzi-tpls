/* src/FCDefs.h.  Generated from FCDefs.h.in by configure.  */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
/* #undef MOAB_FC_FUNC */

/* As MOAB_FC_FUNC, but for C identifiers containing underscores. */
/* #undef MOAB_FC_FUNC_ */
