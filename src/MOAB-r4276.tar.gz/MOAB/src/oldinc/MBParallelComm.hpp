#ifndef MBParallelComm_HEADER
#define MBParallelComm_HEADER

#include "MBInterface.hpp"
#include "MBRange.hpp"
#include "MBProcConfig.hpp"

#include "moab/ParallelComm.hpp"
typedef moab::ParallelComm MBParallelComm;

#endif
