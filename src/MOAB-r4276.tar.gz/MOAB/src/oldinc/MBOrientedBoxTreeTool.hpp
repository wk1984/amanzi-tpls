#ifndef MBOrientedBoxTreeTool_HEADER
#define MBOrientedBoxTreeTool_HEADER

#include "MBForward.hpp"

#include "moab/OrientedBoxTreeTool.hpp"
typedef moab::OrientedBoxTreeTool MBOrientedBoxTreeTool;

#endif
