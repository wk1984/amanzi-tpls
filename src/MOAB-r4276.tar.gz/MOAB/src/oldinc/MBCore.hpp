#ifndef MBCore_HEADER
#define MBCore_HEADER

#include "MBInterface.hpp"
#include "MBReaderIface.hpp"

#include "moab/Core.hpp"
typedef moab::Core MBCore;

#endif
