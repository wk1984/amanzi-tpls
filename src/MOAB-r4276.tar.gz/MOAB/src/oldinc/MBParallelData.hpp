#ifndef MBParallelData_HEADER
#define MBParallelData_HEADER

#include "MBForward.hpp"
#include "MBRange.hpp"

#include "moab/ParallelData.hpp"
typedef moab::ParallelData MBParallelData;

#endif
