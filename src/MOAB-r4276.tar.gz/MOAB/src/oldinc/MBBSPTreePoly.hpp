#ifndef MBBSPTreePoly_HEADER
#define MBBSPTreePoly_HEADER

#include "MBTypes.h"

#include "moab/BSPTreePoly.hpp"
typedef moab::BSPTreePoly MBBSPTreePoly;

#endif
