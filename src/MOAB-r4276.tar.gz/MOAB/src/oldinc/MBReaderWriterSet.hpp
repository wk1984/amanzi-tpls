#ifndef MBReaderWriterSet_HEADER
#define MBReaderWriterSet_HEADER

#include "MBTypes.h"

#include "moab/ReaderWriterSet.hpp"
typedef moab::ReaderWriterSet MBReaderWriterSet;

#endif
