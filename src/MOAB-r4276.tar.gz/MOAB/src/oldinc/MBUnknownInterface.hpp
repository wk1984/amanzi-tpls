#ifndef MBUnknownInterface_HEADER
#define MBUnknownInterface_HEADER
#include "moab/UnknownInterface.hpp"
typedef moab::UnknownInterface MBUnknownInterface;
#endif
