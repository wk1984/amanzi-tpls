#ifndef MBCartVect_HEADER
#define MBCartVect_HEADER

#include "moab/CartVect.hpp"
typedef moab::CartVect MBCartVect;

#endif
