#ifndef MBReadUtilIface_HEADER
#define MBReadUtilIface_HEADER

#include "MBTypes.h"

#include "moab/ReadUtilIface.hpp"
typedef moab::ReadUtilIface MBReadUtilIface;

#endif
