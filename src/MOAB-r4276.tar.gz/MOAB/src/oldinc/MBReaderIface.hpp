#ifndef MBReaderIface_HEADER
#define MBReaderIface_HEADER

#include "MBTypes.h"

#include "moab/ReaderIface.hpp"
typedef moab::ReaderIface MBReaderIface;

#endif
