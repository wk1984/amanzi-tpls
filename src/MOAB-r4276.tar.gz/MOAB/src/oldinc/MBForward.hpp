#ifndef MBForward_HEADER
#define MBForward_HEADER
#include "MBTypes.h"
#include "moab/Forward.hpp"
typedef moab::Interface  MBInterface;
typedef moab::Range      MBRange;
typedef moab::ProcConfig MBProcConfig;
typedef moab::HandleVec  MBHandleVec;
#endif
