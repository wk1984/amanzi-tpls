#ifndef MBUtil_HEADER
#define MBUtil_HEADER

#include "MBForward.hpp"

#include "moab/Util.hpp"
typedef moab::Coord MBCoord;
typedef moab::Util  MBUtil;

#endif
