#ifndef MBmpi_HEADER
#define MBmpi_HEADER
#include "moab_mpi.h"
#endif
