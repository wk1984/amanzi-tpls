uint64_t CycleTime();
