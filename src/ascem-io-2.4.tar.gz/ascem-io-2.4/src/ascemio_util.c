/*******************************************************************************
* Copyright Notice
*  + 2010-2012 North Carolina State University
*  + 2010-2012 Pacific Northwest National Laboratory
* 
* This file is part of ASCEM-IO.
* 
* ASCEM-IO is free software: you can redistribute it and/or modify
* it under the terms of the GNU Lesser General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* any later version.
* 
* ASCEM-IO is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Lesser General Public License for more details.
* 
* You should have received a copy of the GNU Lesser General Public License
* along with ASCEM-IO.  If not, see <http://www.gnu.org/licenses/>.
* 
*******************************************************************************/
#include "ascemio_util.h"

// Set debugging level. 
#if defined(ASCEMIO_DEBUG)
	// Stores current debugging level to print messages.
	int ascemio_debug = ASCEMIO_DEBUG;
#else
	int ascemio_debug = 0;
#endif

ascemio_debuginfo_t ascemio_debuginfo; 

void ascemio_debuglog_init(int rank)
{
	// Set stderr to line buffering mode. Printing out once a '\n' is encountered. This is useful to separate log messages from different processes (parallel)
	setlinebuf(stderr);

	ascemio_debuginfo.rank = rank;
}

/** 
 * @brief Helper function to log messages to stdout
 * 
 * @param ascemio_loglevel ascemio_loglevel applicable to this message
 * @param format format string similar to printf format
 * @param ... variable argument list that is passed on to printf
 */
void ascemio_printmsg(ascemio_loglevel_t ascemio_loglevel, const char *format, ...)
{
	va_list varargs;

	// Sarat: if -DASCEMIO_DEBUG is given in CFLAGS, debug is initialized to 1. If -DASCEMIO_DEBUG=NUM is used, then debug=NUM
	/* printf("\n ascemio_debug level: %d, ascemio_loglevel: %d", ascemio_debug, ascemio_loglevel); */

	// If current message's level is greater (more verbose) than debug level (defined at compile-time) that message is ignored. 
	if (ascemio_loglevel > ascemio_debug)
	{ 
		/* fprintf(stderr, " Ignoring log message. \n"); */
		return;
	}

	fprintf(stderr, "\n %d:LOG:", ascemio_debuginfo.rank);
	
	switch(ascemio_loglevel)
	{
		case ASCEMIO_VERBOSE: 
			fprintf(stderr, "ASCEMIO_VERBOSE: ");
			break;
		case ASCEMIO_INFO: 
			fprintf(stderr, "ASCEMIO_INFO: ");
			break;
		case ASCEMIO_WARNING:
			fprintf(stderr, "ASCEMIO_WARNING: ");
			break;
		case ASCEMIO_ERROR: 
			fprintf(stderr, "ASCEMIO_ERROR: ");
			break;
	}	

	fprintf(stderr, "%s (%s:%d)--> ", ascemio_debuginfo.function, ascemio_debuginfo.file, ascemio_debuginfo.line );

	/* Start variable parameter list after format */
	va_start(varargs, format);
	vfprintf(stderr, format, varargs);
	va_end(varargs);
	fprintf(stderr, "\n");

	fflush(stderr);

	/* int nvarArgs = va_arg(varargs,int); */
	/* printf("\n %d\n", nvarArgs); */
}
