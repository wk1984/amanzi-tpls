#!/bin/bash -v
mpif90 -c test.f90
mpicc -c parallelIOf.c
mpif90 -o test test.o parallelIOf.o -L.. -lparallelio -L/soft/hdf5/default -lhdf5 -lz
