NOTE: regardless of which buildsystem is used, you must define "HAVE_PFLOTRAN" or "HAVE_CRUNCH" to build a particular interface into alquimia!

