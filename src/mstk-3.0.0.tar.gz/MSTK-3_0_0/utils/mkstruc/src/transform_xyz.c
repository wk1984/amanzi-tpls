#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mkstruc.h"

void transform_xyz(double *xyz, int boundary) {

  if (boundary) {
    /* do something or nothing */
  }
  else {
    /* do something else */
  }

}
