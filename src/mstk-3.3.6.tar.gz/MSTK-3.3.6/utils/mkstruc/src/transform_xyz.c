/* 
Copyright 2019 Triad National Security, LLC. All rights reserved.

This file is part of the MSTK project. Please see the license file at
the root of this repository or at
https://github.com/MeshToolkit/MSTK/blob/master/LICENSE
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mkstruc.h"

void transform_xyz(double *xyz, int boundary) {

  if (boundary) {
    /* do something or nothing */
  }
  else {
    /* do something else */
  }

}
