#include <netcdf_meta.h>
#if !defined(NC_HAS_PNETCDF) || NC_HAS_PNETCDF == 0
      choke me
#endif
int main() {return 0;}
